export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// Login URL for the Jevalis client auth system
export const getLoginUrl = () => "/login";
